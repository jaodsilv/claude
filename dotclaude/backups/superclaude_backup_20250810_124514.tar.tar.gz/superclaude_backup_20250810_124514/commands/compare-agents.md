---
name: compare-agents
description: Compares a list of agents
---

Arguments: <arguments>$ARGUMENTS</arguments>
Agent-Comparer: <agent-comparer>agent-comparer</agent-comparer>
Agent-Comparer-2: <agent-comparer-2>agent-comparer-2</agent-comparer-2>

Parse arguments to extract the content on the tag <agent-names> and set their values to $AGENT_NAMES respectivelly

Launch the agent `agent-comparer` to compare those agents with the following parameters:

<agent-names>$AGENT_NAMES</agent-names>

