---
name: learn
description: Learns from a set of urls and creates a new documentation file for Claude Code
---

Arguments: <arguments>$ARGUMENTS</arguments>

Parse arguments to extract the content on the tags <document-name>, <document-learner> and <urls>, and set their values to $DOCUMENT_NAME, $DOCUMENT_LEARNER and $URLS respectivelly

If <document-name> was provided, launch the agent $DOCUMENT_LEARNER to learn the documentation from the urls and write a documentation with the following parameters:

<document-name>$DOCUMENT_NAME</document-name>
<urls>$URLS</urls>
