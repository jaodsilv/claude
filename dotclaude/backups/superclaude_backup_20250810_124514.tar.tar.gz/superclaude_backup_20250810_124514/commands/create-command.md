---
name: create-command
description: Creates a new command
---

Arguments: <arguments>$ARGUMENTS</arguments>

Parse arguments to extract the content on the tags <command-name> and <task> and their values to $COMMAND_NAME and $TASK respectivelly

Launch the agent `command-writer` to write a command with the following parameters:

<command-name>$COMMAND_NAME</command-name>
<task>$TASK</task>
