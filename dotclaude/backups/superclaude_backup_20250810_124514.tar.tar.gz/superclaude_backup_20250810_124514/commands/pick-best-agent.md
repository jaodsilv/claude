---
name: pick-best-agent
description: Picks the best agent from a list of agents
---

Arguments: <arguments>$ARGUMENTS</arguments>
Agent-Comparer: <agent-comparer>agent-comparer</agent-comparer>
Agent-Comparer-2: <agent-comparer-2>agent-comparer-2</agent-comparer-2>

Parse arguments to extract the content on the tag <agent-names> and set their values to $AGENT_NAMES respectivelly

Launch the agent `agent-comparer` to compare those agents with the following parameters. Ask the agent to print ONLY the name of the agent that is the best, or both names if they are equal:

<agent-names>$AGENT_NAMES</agent-names>

Launch the agent `agent-comparer-2` to compare those agents with the following parameters. Ask the agent to print ONLY the name of the agent that is the best, or both names if they are equal:

<agent-names>$AGENT_NAMES</agent-names>

If both comparers agree on the same agent, print the name of the agent. If they disagree, print an error message.

Print the name of the winner and only the name, nothing else.

Example:

User: "/pick-best-agent <agent-names>[new-agent, current-agent]</agent-names>"
Assistant: "new-agent"
