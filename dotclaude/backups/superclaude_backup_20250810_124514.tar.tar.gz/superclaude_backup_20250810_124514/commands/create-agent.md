---
name: create-agent
description: Creates a new agent
---

Arguments: <arguments>$ARGUMENTS</arguments>

Parse arguments to extract the content on the tags <agent-name>, <agent-creator> and <task> and their values to $AGENT_NAME, $AGENT_CREATOR and $TASK respectivelly

Launch the agent $AGENT_CREATOR to write an agent with the following parameters:

<agent-name>$AGENT_NAME</agent-name>
<task>$TASK</task>

Remind the agent to not use Opus model, but set a proper thinking level for the complexity of each step of the task as tokens usage is also an important metric.
